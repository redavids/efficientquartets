#!/bin/bash
eff_on=0 #efficient quartets off by default
check_on=0 #check quartet off by default
if [ $# -eq 0 ] 
then
	echo "Need arguments in form ./treequar.sh [opts] tree_file outfile"
	exit 1
fi
while getopts ":ec" opt
do
	case $opt in
		e)
			eff_on=1
			;;
		c)
			check_on=1
			;;
		\?)
			echo "Invalid Option: -$OPTARG"
			;;
	esac
done
shift $((OPTIND-1))
arr=("$@")
infile=${arr[0]}
outfile=${arr[1]}
echo "`cat $infile > intree`"
newfile="intree2"
distopts="R\nD\n2\nC\nV\nY\n"
if [ $eff_on -eq 1 ]
then
	echo "`python2.7 treemeth.py $infile $outfile eff`"
else
	echo "`python2.7 treemeth.py $infile $outfile`"
fi	
if [ $check_on -eq 1 ]
then 
	echo "`./find-cut-Linux-64 qrtt=$outfile otre=$newfile`"
	d="`echo -e $distopts | ./treedist`"
	echo "treedist run, look in outfile for result"
fi
